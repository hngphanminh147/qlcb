-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dbo.CHUYENBAY`
--

DROP TABLE IF EXISTS `dbo.CHUYENBAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.CHUYENBAY` (
  `MACB` smallint(6) DEFAULT NULL,
  `SBDI` varchar(3) DEFAULT NULL,
  `SBDEN` varchar(3) DEFAULT NULL,
  `GIODI` varchar(8) DEFAULT NULL,
  `GIODEN` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.CHUYENBAY`
--

LOCK TABLES `dbo.CHUYENBAY` WRITE;
/*!40000 ALTER TABLE `dbo.CHUYENBAY` DISABLE KEYS */;
INSERT INTO `dbo.CHUYENBAY` VALUES (100,'SLC','BOS','08:00:00','17:50:00'),(112,'DCA','DEN','14:00:00','18:07:00'),(121,'STL','SLC','07:00:00','09:13:00'),(122,'STL','YYV','08:30:00','10:19:00'),(206,'DFW','STL','09:00:00','11:40:00'),(330,'JFK','YYV','16:00:00','18:53:00'),(334,'ORD','MIA','12:00:00','14:14:00'),(335,'MIA','ORD','15:00:00','17:14:00'),(336,'ORD','MIA','18:00:00','20:14:00'),(337,'MIA','ORD','20:30:00','23:53:00'),(394,'DFW','MIA','19:00:00','21:30:00'),(395,'MIA','DFW','21:00:00','23:43:00'),(449,'CDG','DEN','10:00:00','19:29:00'),(930,'YYV','DCA','13:00:00','16:10:00'),(931,'DCA','YYV','17:00:00','18:10:00'),(932,'DCA','YYV','18:00:00','19:10:00'),(991,'BOS','ORD','17:00:00','18:22:00');
/*!40000 ALTER TABLE `dbo.CHUYENBAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.DATCHO`
--

DROP TABLE IF EXISTS `dbo.DATCHO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.DATCHO` (
  `MAKH` varchar(0) DEFAULT NULL,
  `NGAYDI` varchar(0) DEFAULT NULL,
  `MACB` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.DATCHO`
--

LOCK TABLES `dbo.DATCHO` WRITE;
/*!40000 ALTER TABLE `dbo.DATCHO` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo.DATCHO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.KHACHHANG`
--

DROP TABLE IF EXISTS `dbo.KHACHHANG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.KHACHHANG` (
  `MAKH` smallint(6) DEFAULT NULL,
  `TEN` varchar(6) DEFAULT NULL,
  `DCHI` varchar(15) DEFAULT NULL,
  `DTHOAI` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.KHACHHANG`
--

LOCK TABLES `dbo.KHACHHANG` WRITE;
/*!40000 ALTER TABLE `dbo.KHACHHANG` DISABLE KEYS */;
INSERT INTO `dbo.KHACHHANG` VALUES (9,'Nga','223 Nguyen Trai','8932320'),(12,'Ha','435 Quang Trung','8933232'),(45,'Thu','285 Le Loi','8932203'),(91,'Hai','345 Hung Vuong','8893223'),(101,'Anh','567 Tran Phu','8826729'),(238,'Hung','456 Pasteur','9812101'),(314,'Phuong','395 Vo Van Tan','8232320'),(397,'Thanh','234 Le Van Si','8952943'),(422,'Tien','123 Bach Dang','8332222'),(582,'Mai','789 Nguyen Du',''),(586,'Son','123 Bach Dang','8556223'),(613,'Vu','348 CMT8','8343232'),(934,'Minh','678 Le Lai','');
/*!40000 ALTER TABLE `dbo.KHACHHANG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.KHANANG`
--

DROP TABLE IF EXISTS `dbo.KHANANG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.KHANANG` (
  `MANV` varchar(0) DEFAULT NULL,
  `MALOAI` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.KHANANG`
--

LOCK TABLES `dbo.KHANANG` WRITE;
/*!40000 ALTER TABLE `dbo.KHANANG` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo.KHANANG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.LICHBAY`
--

DROP TABLE IF EXISTS `dbo.LICHBAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.LICHBAY` (
  `NGAYDI` varchar(19) DEFAULT NULL,
  `MACB` smallint(6) DEFAULT NULL,
  `SOHIEU` varchar(2) DEFAULT NULL,
  `MALOAI` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.LICHBAY`
--

LOCK TABLES `dbo.LICHBAY` WRITE;
/*!40000 ALTER TABLE `dbo.LICHBAY` DISABLE KEYS */;
INSERT INTO `dbo.LICHBAY` VALUES ('1894-06-20 00:00:00',100,'',''),('1894-06-20 00:00:00',112,'',''),('1894-06-20 00:00:00',206,'',''),('1894-06-20 00:00:00',334,'',''),('1894-06-20 00:00:00',335,'',''),('1894-06-20 00:00:00',337,'',''),('1894-06-20 00:00:00',449,'',''),('1894-07-21 00:00:00',100,'80','A310'),('1894-07-21 00:00:00',112,'21','DC10'),('1894-07-21 00:00:00',206,'',''),('1894-07-21 00:00:00',334,'',''),('1894-07-21 00:00:00',337,'',''),('1894-07-21 00:00:00',395,'',''),('1894-07-21 00:00:00',991,'','');
/*!40000 ALTER TABLE `dbo.LICHBAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.LOAIMB`
--

DROP TABLE IF EXISTS `dbo.LOAIMB`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.LOAIMB` (
  `HANGSX` varchar(6) DEFAULT NULL,
  `MALOAI` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.LOAIMB`
--

LOCK TABLES `dbo.LOAIMB` WRITE;
/*!40000 ALTER TABLE `dbo.LOAIMB` DISABLE KEYS */;
INSERT INTO `dbo.LOAIMB` VALUES ('Airbus','A310'),('Airbus','A320'),('Airbus','A330'),('Airbus','A340'),('Boeing','B727'),('Boeing','B747'),('Boeing','B757'),('MD','DC10'),('MD','DC9');
/*!40000 ALTER TABLE `dbo.LOAIMB` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.MAYBAY`
--

DROP TABLE IF EXISTS `dbo.MAYBAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.MAYBAY` (
  `SOHIEU` tinyint(4) DEFAULT NULL,
  `MALOAI` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.MAYBAY`
--

LOCK TABLES `dbo.MAYBAY` WRITE;
/*!40000 ALTER TABLE `dbo.MAYBAY` DISABLE KEYS */;
INSERT INTO `dbo.MAYBAY` VALUES (10,'B747'),(11,'B727'),(13,'B727'),(13,'B747'),(21,'DC10'),(21,'DC9'),(22,'B757'),(22,'DC9'),(23,'DC9'),(24,'DC9'),(70,'A310'),(80,'A310'),(93,'B757');
/*!40000 ALTER TABLE `dbo.MAYBAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.NHANVIEN`
--

DROP TABLE IF EXISTS `dbo.NHANVIEN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.NHANVIEN` (
  `MANV` smallint(6) DEFAULT NULL,
  `TEN` varchar(6) DEFAULT NULL,
  `DCHI` varchar(18) DEFAULT NULL,
  `DTHOAI` int(11) DEFAULT NULL,
  `LUONG` decimal(7,1) DEFAULT NULL,
  `LOAINV` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.NHANVIEN`
--

LOCK TABLES `dbo.NHANVIEN` WRITE;
/*!40000 ALTER TABLE `dbo.NHANVIEN` DISABLE KEYS */;
INSERT INTO `dbo.NHANVIEN` VALUES (1001,'Huong','8 Dien Bien Phu',8330733,500000.0,1),(1002,'Phong','1 Ly Thuong Kiet',8308117,450000.0,1),(1003,'Quang','78 Truong Dinh',8324461,350000.0,1),(1004,'Phuong','351 Lac Long Quan',8308155,250000.0,1),(1005,'Giao','65 Nguyen Thai Son',8324467,500000.0,0),(1006,'Chi','12/6,Nguyen Kiem',8120012,150000.0,0),(1007,'Tam','36 Nguyen Van Cu',8458188,500000.0,0);
/*!40000 ALTER TABLE `dbo.NHANVIEN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo.PHANCONG`
--

DROP TABLE IF EXISTS `dbo.PHANCONG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbo.PHANCONG` (
  `MANV` varchar(0) DEFAULT NULL,
  `NGAYDI` varchar(0) DEFAULT NULL,
  `MACB` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo.PHANCONG`
--

LOCK TABLES `dbo.PHANCONG` WRITE;
/*!40000 ALTER TABLE `dbo.PHANCONG` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo.PHANCONG` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-22 15:20:28
